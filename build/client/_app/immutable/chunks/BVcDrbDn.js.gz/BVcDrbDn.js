import{n as a}from"./B64TLU0q.js";a();
