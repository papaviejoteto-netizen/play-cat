import{b as r,r as o}from"./CYHOywpD.js";const t="";function a(...e){return r+t+o(e[0],e[1])}export{a as r};
