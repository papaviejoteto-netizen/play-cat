import{D as o}from"./B64TLU0q.js";const s=o;export{s as d};
