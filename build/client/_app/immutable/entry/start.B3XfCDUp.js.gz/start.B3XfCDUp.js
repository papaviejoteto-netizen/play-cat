import{l as o,d as r}from"../chunks/BX0c1fD1.js";export{o as load_css,r as start};
